class GoalEngine:
    def evaluate(self,goals):
        return goals
