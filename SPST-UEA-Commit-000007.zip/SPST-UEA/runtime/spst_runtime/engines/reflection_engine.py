class ReflectionEngine:
    def review(self,candidate):
        return {"approved":True,"candidate":candidate}
