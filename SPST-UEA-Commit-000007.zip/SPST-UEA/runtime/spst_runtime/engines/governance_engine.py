class GovernanceEngine:
    def authorize(self,action)->bool:
        return True
