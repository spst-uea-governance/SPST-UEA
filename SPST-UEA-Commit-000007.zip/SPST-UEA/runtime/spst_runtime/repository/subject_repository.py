from spst_runtime.models.subject_state import SubjectState

class SubjectRepository:
    def __init__(self):
        self._state=SubjectState()
    def load(self)->SubjectState:
        return self._state
    def save(self,state:SubjectState)->None:
        self._state=state
