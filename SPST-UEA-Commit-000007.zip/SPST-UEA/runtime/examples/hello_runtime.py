print("Hello SPST Runtime")
