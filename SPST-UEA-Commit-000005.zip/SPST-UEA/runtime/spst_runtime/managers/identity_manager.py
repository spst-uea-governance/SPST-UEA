class IdentityManager:
    pass
