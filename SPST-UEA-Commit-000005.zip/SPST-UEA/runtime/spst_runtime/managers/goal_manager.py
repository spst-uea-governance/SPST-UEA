class GoalManager:
    pass
