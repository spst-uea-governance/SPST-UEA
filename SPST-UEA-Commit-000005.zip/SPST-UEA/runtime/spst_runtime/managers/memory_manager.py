class MemoryManager:
    pass
