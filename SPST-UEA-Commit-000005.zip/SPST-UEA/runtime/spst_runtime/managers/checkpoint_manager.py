class CheckpointManager:
    pass
