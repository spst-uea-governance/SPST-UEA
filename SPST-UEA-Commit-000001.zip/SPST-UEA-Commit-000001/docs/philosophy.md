# Philosophy
Evidence First.
