from spst_runtime.pipeline.state_transition import StateTransitionPipeline

def test_pipeline():
    p=StateTransitionPipeline()
    assert p.run({},None)=={}
