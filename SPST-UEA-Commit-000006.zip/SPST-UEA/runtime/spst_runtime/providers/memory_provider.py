from abc import ABC, abstractmethod

class MemoryProvider(ABC):
    @abstractmethod
    def health(self)->bool:
        ...
