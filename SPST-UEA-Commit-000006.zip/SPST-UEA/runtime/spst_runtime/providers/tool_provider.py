from abc import ABC, abstractmethod

class ToolProvider(ABC):
    @abstractmethod
    def health(self)->bool:
        ...
