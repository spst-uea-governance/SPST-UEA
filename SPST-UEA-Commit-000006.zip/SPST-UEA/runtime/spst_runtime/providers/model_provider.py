from abc import ABC, abstractmethod

class ModelProvider(ABC):
    @abstractmethod
    def health(self)->bool:
        ...
