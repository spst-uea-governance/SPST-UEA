from spst_runtime.bus.event_bus import EventBus
from spst_runtime.pipeline.state_transition import StateTransitionPipeline

class RuntimeOrchestrator:
    def __init__(self):
        self.bus=EventBus()
        self.pipeline=StateTransitionPipeline()

    def dispatch(self,state,event):
        self.bus.publish(event)
        return self.pipeline.run(state,event)
