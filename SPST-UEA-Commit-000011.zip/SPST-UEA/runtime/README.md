# Runtime Baseline 0.1

## Development

```bash
pip install -e .[dev]
pytest
ruff check .
mypy spst_runtime
```
