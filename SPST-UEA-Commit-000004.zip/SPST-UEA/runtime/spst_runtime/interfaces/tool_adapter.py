from abc import ABC

class ToolAdapter(ABC):
    """SPST interface."""
    pass
