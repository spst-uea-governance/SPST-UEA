from abc import ABC

class Memory(ABC):
    """SPST interface."""
    pass
