from abc import ABC

class ModelAdapter(ABC):
    """SPST interface."""
    pass
