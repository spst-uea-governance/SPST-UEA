from spst_runtime.models.subject_state import SubjectState
from spst_runtime.events.event import Event

class RuntimeEngine:
    def __init__(self):
        self.state=SubjectState()

    def dispatch(self,event: Event)->SubjectState:
        # Placeholder dispatch pipeline
        return self.state
