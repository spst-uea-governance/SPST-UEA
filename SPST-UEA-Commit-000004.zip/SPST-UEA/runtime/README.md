# SPST Runtime

Reference runtime skeleton for SPST-UEA.
