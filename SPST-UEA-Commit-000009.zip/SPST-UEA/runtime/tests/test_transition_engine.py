from spst_runtime.pipeline.transition_engine import TransitionEngine
from spst_runtime.models.subject_state import SubjectState

def test_trace():
    s=SubjectState()
    out=TransitionEngine().execute(s,None)
    assert out.metadata["last_trace"][0]=="observe"
