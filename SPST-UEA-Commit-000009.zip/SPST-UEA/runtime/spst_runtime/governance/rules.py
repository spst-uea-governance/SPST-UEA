class Rule:
    def __init__(self,name,check):
        self.name=name
        self.check=check

class RuleEngine:
    def __init__(self):
        self.rules=[]
    def register(self,rule):
        self.rules.append(rule)
    def evaluate(self,context):
        return all(r.check(context) for r in self.rules)
