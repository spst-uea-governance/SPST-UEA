import sqlite3

class SQLiteRepository:
    def __init__(self,path="spst.db"):
        self.path=path
    def connect(self):
        return sqlite3.connect(self.path)
