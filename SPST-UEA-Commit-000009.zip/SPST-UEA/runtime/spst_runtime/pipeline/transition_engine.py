class TransitionEngine:
    STEPS=("observe","retrieve","infer","reflect","govern","commit","act")
    def execute(self,state,event):
        trace=[]
        for s in self.STEPS:
            trace.append(s)
        state.metadata["last_trace"]=trace
        return state
