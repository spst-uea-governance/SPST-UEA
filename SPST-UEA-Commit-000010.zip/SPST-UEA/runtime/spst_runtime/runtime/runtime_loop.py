from dataclasses import dataclass, field

@dataclass
class RuntimeContext:
    running: bool = False
    tick: int = 0
    history: list[str] = field(default_factory=list)

class RuntimeLoop:
    def __init__(self):
        self.ctx = RuntimeContext()

    def start(self):
        self.ctx.running = True

    def stop(self):
        self.ctx.running = False

    def step(self):
        if not self.ctx.running:
            return
        self.ctx.tick += 1
        self.ctx.history.append(f"tick:{self.ctx.tick}")
