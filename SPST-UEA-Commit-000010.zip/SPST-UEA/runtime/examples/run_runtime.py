from spst_runtime.runtime.runtime_loop import RuntimeLoop

rt=RuntimeLoop()
rt.start()
for _ in range(3):
    rt.step()
print(rt.ctx)
